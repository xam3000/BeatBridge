---
name: multi-session-project-discipline
description: Arbeitsdisziplin für Softwareprojekte, die über viele AI-Sessions und mehrere Agenten laufen. Docs-als-Gedächtnis (vier Dokumentrollen), Session-Hygiene, Verifikations- und Diagnose-Disziplin (Messen statt Raten, Schritt-Tags, Drei-Anläufe-Regel), Kreuz-Review, Optimierungs-Hebel-Leiter. Anwenden bei - neues längeres Projekt aufsetzen, Projektdoku strukturieren, Multi-Session-Workflow, Agenten-Rollenteilung, Debugging-Eskalation, Performance-Arbeit, "wie arbeiten wir hier", project discipline, working agreement, session hygiene.
---

# Multi-Session-Projekt-Disziplin

Destillat aus einem realen Projekt (macOS-App + Python-Pipeline, Juli 2026),
das in ~zwei Wochen von der Idee zur getesteten Werkbank kam — mit einem
Menschen, zwei Modellen (Bau ↔ Review) und Dutzenden Sessions. Jede Regel
hier wurde durch einen Fehler bezahlt. Wo ein Datum steht, gab es den Vorfall.

## 1. Kernprinzip: Die Docs sind das Gedächtnis

Chat-Verläufe sind flüchtig: Sessions enden, Kontexte werden komprimiert,
Modelle wechseln, Assistenz-Gedächtnisse wandern nicht mit. Was überleben
soll, steht in Dateien im Repo — **sofort**, nicht am Session-Ende.

Korollar (bitter gelernt): **Deliverables nie ausschließlich an temporäre
Orte** (Chat-Anhänge, Scratch-/Output-Ordner). Die erste Fassung dieses
Skills ging genau so verloren.

## 2. Vier Dokumente, vier Rollen

Beim Projektstart anlegen (Namen anpassen, Rollen beibehalten):

| Rolle | typische Datei | Regel |
|---|---|---|
| Konventionen | `CLAUDE.md` / `AGENTS.md` | Nicht verhandelbare Regeln + Pflichtlektüre-Liste. KURZ — wird jede Session geladen |
| Einstieg | `docs/STATUS.md` | Verifizierter Stand, Landkarte (Datei→Rolle), offene Brocken priorisiert. Bei Meilensteinen aktualisieren |
| Verträge | `docs/<PROTOCOL>.md` | Schnittstellen, eingefrorene Formate, Architektur-Entscheidungen. Änderungen nur additiv |
| Log | `FEATURES.md` o. ä. | Backlog, Entscheidungen (Datum + Begründung), *Gelernt*-Notizen. Nichts löschen — abhaken und stehen lassen |

Bei Widersprüchen: explizite Doc-Entscheidung schlägt Screenshot/Prototyp
schlägt Chat-Erinnerung. Doppelte Backlog-Einträge sofort zusammenziehen
(einer wird sonst irgendwann falsch abgehakt).

## 3. Entscheidungen und Sackgassen festhalten

- Entscheidungen mit **Datum und Begründung** — die Begründung verhindert,
  dass eine spätere Session die Entscheidung „wegoptimiert“.
- **Sackgassen sind Dokumentations-Gold.** Format: *Gelernt (Datum,
  n-ter Versuch): Symptom → Ursache → Regel.* Verhindert nachweislich,
  dass derselbe Fehler zweimal gebaut wird.
- **Workarounds sind Schulden mit Etikett:** ein funktionierender Hack
  bekommt SOFORT einen Backlog-Eintrag „idiomatisch später“ samt Forensik,
  warum der saubere Weg scheiterte. So wird er ersetzt statt zu versteinern.

## 4. Session-Disziplin

- **Ein Thema pro Session.** Frisch bei: Themenwechsel, Meilenstein,
  vielen Debug-Sackgassen, Baustellenwechsel. Fortsetzen bei:
  messgestützter Iteration am selben Problem (der Versuchsverlauf ist
  dann wertvoller Kontext — z. B. Performance-Hebel 2 in derselben
  Session wie Hebel 1, weil Messwerkzeug und Baseline dort leben).
- **Plan-Modus an** bei: neuen Datei-/Artefakt-Formaten (werden
  eingefroren), Architektur-/Mehrdatei-Umbauten, vagen Aufgaben. Aus bei:
  Checklisten, Fixes mit bekannter Ursache. Große Pläne als Datei ins
  Repo und extern reviewen lassen, bevor gebaut wird.
- **Scoping-Regel im Plan:** bei Optionen die wählen, deren Ergebnis
  NICHT in laufenden Zustand zurückfließen muss. Kein „UI nebenbei“.
- **Effort-Ökonomie:** Denktiefe einkaufen, wo die Falle im SCHLUSSFOLGERN
  steckt — Planen/Reviewen hoch, Bauen nach Plan normal, mechanische
  Fixes mit fertiger Diagnose niedrig. Fehlende *Empirie* kauft man nicht
  mit Denktiefe (kein Thinking-Level findet einen Lebensdauer-Bug — ein
  Log-Tag schon).
- **Unbeaufsichtigte (Nacht-)Arbeit** nur für maschinell Verifizierbares,
  nie auf uncommittetem Baum. Realität einplanen: UI-/E2E-Automation
  braucht menschliche Einmal-Freigaben, die Reboots nicht überleben;
  ein wartender Auth-Dialog bei gesperrtem Bildschirm kann Test-Daemons
  verklemmen. Nachts: nur daemonfreie Logik-Tests.
- Erkenntnisse vor Session-Ende in die Docs. Vor Architektur-Refactors
  IMMER committen — kein sauberes Zurück ist der teuerste Zustand.

## 5. Verifikations-Disziplin

- Maschinell, was maschinell geht: Build nach jedem Schritt, headless
  Logik-Tests, **Golden-Fixtures als Verträge** an Schnittstellen.
- **Den Durchklick macht der Mensch** — er findet UX-Reibung, die kein
  Test sieht; „Reibungslisten aus echter Nutzung“ sind die beste
  Feature-Quelle. Erst benutzen, dann bauen.
- **Keine Ad-hoc-UI-Automation** (kämpft mit dem Menschen um Maus/Fokus).
  Robustes E2E nur geplant. Test-Validität: ein *ausgeblendetes* UI ist
  kein *deaktivierter* Codepfad.
- **Berichte stichprobenartig verifizieren:** meldet ein Agent „fertig,
  alles grün“, 2–3 tragende Behauptungen mit Ein-Minuten-Checks prüfen
  (ls/grep/Doku-Eintrag). Klassische Lücke: `git add -u` staged neue
  Dateien NICHT — neue Testdatei vergessen = kaputter Commit für jeden
  frischen Checkout.
- **Kein stiller Guard:** jede Nutzer-Aktion tut etwas oder sagt, warum
  nicht. Ausgegraut ohne Erklärung ist eine Sackgasse — lieber klickbar
  lassen und per Preflight-Dialog die konkrete Ursache nennen.

## 6. Diagnose-Disziplin: Messen statt Raten

Die teuerste Lektion, mehrfach bezahlt:

- **Drei-Anläufe-Regel:** nach spätestens zwei, drei gescheiterten
  Fern-Hypothesen STOPP — keine vierte Hypothese, sondern
  Instrumentierung. Jede Blind-Hypothese kostet den Menschen einen
  Build-Zyklus; ein Diagnose-Log kostet fünf Minuten und beantwortet alles.
- **Fehlerpfade früh mit Schritt-Tags versehen** (`[Schritt X] Fehler …`):
  macht aus jedem künftigen Fehlschlag eine Ortsangabe statt einer
  Vermutung. Ein Bug überlebte drei Umbauten und fiel in EINEM Lauf,
  sobald das Tag den werfenden Schritt nannte.
- **Bei Framework-Fehlern zuerst Objekt-LEBENSDAUERN/Ownership prüfen,
  dann Parameter** (der Klassiker: ein Temporary war beim Aufruf schon
  dealloziert — die Parameter waren nie das Problem).
- **Standard-Werkzeug kaputt? Mini-Sonde bauen** statt blind optimieren
  (z. B. DEBUG-only Body-Zähler + Heartbeat-Stall-Messung, wenn der
  Profiler nicht läuft). Vorher/Nachher-Zahlen oder es zählt nicht.
- **Symptom-Differentiale ernst nehmen:** „tritt NUR unter Bedingung X
  auf“ benennt den Täter präziser als jedes Profiling — erst überlegen,
  welches Experiment Hypothesen unterscheidet, dann messen.
- **Performance-Gefühl am Release-Build beurteilen** — Debug verzerrt;
  sonst optimiert man das falsche Artefakt.

## 7. Rollenteilung und Kreuz-Review

- **Mensch:** committet ausschließlich selbst, entscheidet Richtung,
  macht den Durchklick, liefert Reibungslisten.
- **Bau-Agent:** baut, verifiziert per Build/Tests, meldet ehrlich, was
  es nicht selbst testen konnte.
- **Architektur-Kanal:** Verträge, Doku-Pflege, Plan-Reviews, Diagnosen,
  Session-Prompts (immer mit Session-/Plan-Modus-/Effort-Empfehlung).
- **Kreuz-Review:** Wer baut, wird vom ANDEREN Modell in frischer Session
  streng reviewt — frische Augen heißt anderer KONTEXT, nicht nur anderes
  Modell (der Bauende reviewt sich sonst mit denselben blinden Flecken).
  Review-Audits als eigenes Genre ins Log: verifizierte **Invarianten**
  (worauf künftige Sessions bauen dürfen) + **latente Beobachtungen**
  (bewusst kein Fix, aber benannt).

## 8. Technische Leitplanken

- **Eine Autorität pro veränderlicher Ressource** (Zeit, Fokus, Zustand).
  Verletzungen waren die Quelle der schwersten Bugs.
- **Verträge an Grenzen einfrieren, dahinter frei iterieren**; Änderungen
  nur additiv, `format_version` von Anfang an; optionale neue Felder so,
  dass alte Dateien lesbar bleiben.
- **Daten statt Bilder durch Schnittstellen**; **Domänenwissen als Daten,
  nicht Code** (Fachänderung = Datenupdate, kein Release).
- **Originale read-only**; Edits als eigene Artefakte mit Provenienz;
  destruktiv = archivieren statt löschen; Schreiben atomar (Temp+Rename).
- **Beispiel-Pfade in Docstrings sind ECHTE relative Pfade**, nie
  `…`-Platzhalter — wörtlich ausgeführt entstehen sonst Ordner namens
  `...` samt sensibler Dumps im Repo.
- Personenbezogene Daten (echte Aufnahmen o. ä.) niemals in Fixtures oder
  Repos — synthetische Testdaten generieren.

## 9. Optimierungs-Disziplin: die Hebel-Leiter

Hypothesen in Verdachtsreihenfolge dokumentieren → Baseline messen →
EINEN Hebel ziehen → wieder messen → Nutzer-Urteil. **Abbruchkriterium:
sobald der nächste Hebel Sichtbares verschlechtern würde oder gegen die
Plattform arbeitet, aufhören — der erste unidiomatische Hebel ist der
letzte.** Framework-Grundrauschen akzeptieren. Nicht gezogene
Reserve-Hebel dokumentieren, dazu den *idiomatischen Endzustand*, falls
das Thema wieder aufmacht. „Gut genug“ ist eine Entscheidung und wird
wie eine notiert: Datum + Begründung.

## 10. Anwendung bei Projektstart (Checkliste)

1. Vier Docs anlegen (Rollen aus §2), Konventionen-Datei mit den
   Nicht-Verhandelbaren des Projekts (wer committet, was ist die eine
   Autorität, was ist eingefroren).
2. Erste Verträge/Formate mit `format_version` + Additiv-Regel notieren.
3. Session-Rhythmus etablieren: bauen → Mensch klickt → Reibungsliste →
   nächste Runde; Kreuz-Review bei Meilensteinen.
4. Ab dem ersten Fehler: Gelernt-Notizen im Log-Format; ab dem ersten
   zähen Bug: §6 anwenden.
